hostname
whoami
echo Hello, World!
pwd
mkdir dirA dirB dirC
ls
cd dirA
touch fileA
cd ..
cd dirB
touch fileB
cd ..
cd dirC
touch fileC
cd ..
ls
rm -r dirA dirB dirC

